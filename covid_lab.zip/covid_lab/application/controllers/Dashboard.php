<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends Admin_Controller {
	  function __construct()
    {
        parent::__construct();
        $this->load->model('User_model');
        $this->load->model('Patients_model');
        $this->load->model('Test_identifiers_model');
        $this->load->model('Results_model');
      
    } 
	public function index()
	{
		  $data['users_count'] = $this->User_model->users_count();
		    $data['patients_count'] = $this->Patients_model->patients_count();
		     $data['test_identifiers_count'] = $this->Test_identifiers_model->test_identifiers_count();
		       $data['results_count'] = $this->Results_model->results_count();
		 
        $data['_view'] = 'dashboard';
		$this->load->view('layouts/main',$data);
	}
}
