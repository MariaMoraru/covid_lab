<div class="row">
    <div class="col-md-12">
        <h2>Add patients</h2>
    </div>
</div>

<?php echo form_open('patients/edit/'.$patients['id'],array("class"=>"form-horizontal")); ?>
<div class="row">
     <div class="col-md-4">
                    <label class="control-label">Title</label>
                    <div class="form-group">
                     <select class="form-control"  name="title" id="title" >
                            <option value="">- - - Select - - - </option>
                            <option <?php if($patients['title'] == "Mr") echo "selected"; ?> value="Mr">Mr</option>
                            <option <?php if($patients['title'] == "Mrs") echo "selected"; ?> value="Mrs">Mrs</option>
                            <option <?php if($patients['title'] == "Miss") echo "selected"; ?> value="Miss">Miss</option>
                            <option <?php if($patients['title'] == "Ms") echo "selected"; ?> value="Ms">Ms</option>
                            <option <?php if($patients['title'] == "Dr") echo "selected"; ?> value="Dr">Dr</option>
                           
                                  
                        </select>
                    </div>
                </div>
    <div class="col-md-4">
        <label for="name" class=" control-label"><span class="text-danger">*</span>Name</label>
        <input type="text" name="name" value="<?php echo ($this->input->post('name') ? $this->input->post('name') : $patients['name']); ?>" class="form-control" id="name" required />
        <span class="text-danger"><?php echo form_error('name');?></span>
    </div>
    <div class="col-md-4">
        <label for="surname" class=" control-label"><span class="text-danger">*</span>Surname</label>
        <input type="text" name="surname" value="<?php echo ($this->input->post('surname') ? $this->input->post('surname') : $patients['surname']); ?>" class="form-control" id="name" required />
        <span class="text-danger"><?php echo form_error('surname');?></span>
    </div>
      <div class="col-md-4">
          <label for="gender" class=" control-label"><span class="text-danger">*</span>Gender</label>
          <div class="radio">
            <label style="margin-right: 20px">
              <input type="radio" name="gender" <?php if($patients['gender'] == 1) echo "checked"; ?> value="1" style="margin-right: 10px" checked="checked">Male</label>
            <label>
            <input type="radio" name="gender" <?php if($patients['gender'] == 2) echo "checked"; ?> value="2" style="margin-right: 10px; margin-top: 12px">Female</label>
          </div>
        </div>
         <div class="col-md-4">
        <label for="lab_sub_no" class=" control-label"><span class="text-danger">*</span>Laboratory Submission No</label>
        <input type="text" name="lab_sub_no" value="<?php echo ($this->input->post('lab_sub_no') ? $this->input->post('lab_sub_no') : $patients['lab_sub_no']); ?>" class="form-control" id="name"  readonly/>
        <span class="text-danger"><?php echo form_error('lab_sub_no');?></span>
    </div>
     <div class="col-md-4">
        <label for="tel" class=" control-label"><span class="text-danger">*</span>Tel</label>
        <input type="text" name="tel" value="<?php echo ($this->input->post('tel') ? $this->input->post('tel') : $patients['tel']); ?>" class="form-control" id="tel" required />
        <span class="text-danger"><?php echo form_error('tel');?></span>
    </div>
     <div class="col-md-12">
        <label for="email" class=" control-label"><span class="text-danger">*</span>Email</label>
        <input type="email" name="email" value="<?php echo ($this->input->post('email') ? $this->input->post('email') : $patients['email']); ?>" class="form-control" id="email"  />
        <span class="text-danger"><?php echo form_error('email');?></span>
    </div>


     <div class="col-md-12">
  <label for="address" class=" control-label">Address</label>
        <textarea name="address" rows="6" class="form-control" placeholder="Enter Address ..." id="address" style="resize: none"><?php echo ($this->input->post('address') ? $this->input->post('address') : $patients['address']); ?></textarea>
    </div>

     <div class="col-md-4">
        <label for="date_swab_taken" class=" control-label"><span class="text-danger">*</span>Date swab taken</label>
        <input type="Date" name="date_swab_taken" value="<?php echo $this->input->post('date_swab_taken'); ?>" class="form-control" id="date_swab_taken" required />
        <span class="text-danger"><?php echo form_error('date_swab_taken');?></span>
    </div>

    <div class="col-md-6" style="margin-top: 30px">
        <label class=" control-label">Case definition</label><br>
        <?php echo '<label><strong>Selected Case definition:</strong>'.$patients['case_define'].'</label><br><br>';
         $types = array(
           'Suspected cases' => 'Suspected cases',
            'Screen' => 'Screen',
            'Fit to Fly' => 'Fit to Fly',
            
            );
             $maintent = explode(',',$patients['case_define']);
            // print_r($maintent);
            foreach($types as  $t){ 
                if($t == $maintent[0]){
                    echo "<h3>Checked</h3>";
                }
                ?>
            <label style="font-weight: normal;"><input type="checkbox" name="case_define[]" value="<?=$t?>"/>
            <?=$t?>
            </label><br>
            <?php } ?>
    </div>
    <div class="col-md-6" style="margin-top: 30px; margin-bottom: 20px">
        <label class=" control-label">Specimen information</label><br>
        <?php echo '<label><strong>Selected Specimen information:</strong>'.$patients['specimen_info'].'</label><br><br>';
         $types2 = array(
           'VTM Swab for PCR' => 'VTM Swab for PCR',
            'Blood for Antibody' => 'Blood for Antibody',
            'Both' => 'Both',
            
            );
             $maintent = explode(',',$patients['specimen_info']);
            // print_r($maintent);
            foreach($types2 as  $t){ 
                if($t == $maintent[0]){
                    echo "<h3>Checked</h3>";
                }
                ?>
            <label style="font-weight: normal;"><input type="checkbox" name="specimen_info[]" value="<?=$t?>"/>
            <?=$t?>
            </label><br>
            <?php } ?>
    </div>


    <div class="col-md-4">
        <label for="passport_no" class=" control-label"><span class="text-danger">*</span>Passport Number</label>
        <input type="text" name="passport_no" value="<?php echo ($this->input->post('passport_no') ? $this->input->post('passport_no') : $patients['passport_no']); ?>" class="form-control" id="passport_no"  />
        <span class="text-danger"><?php echo form_error('passport_no');?></span>
    </div>
     <div class="col-md-4">
        <label for="dob" class=" control-label"><span class="text-danger">*</span>Date of Birth</label>
        <input type="Date" name="dob" value="<?php echo ($this->input->post('dob') ? $this->input->post('dob') : $patients['dob']); ?>" class="form-control" id="dob" required />
        <span class="text-danger"><?php echo form_error('dob');?></span>
    </div>

      <!-- <div class="col-md-4">
        <label for="relevant_info" class=" control-label"><span class="text-danger">*</span>Relevant information</label>
        <input type="text" name="relevant_info" value="<?php echo ($this->input->post('relevant_info') ? $this->input->post('relevant_info') : $patients['relevant_info']); ?>" class="form-control" id="relevant_info" />
        <span class="text-danger"><?php echo form_error('relevant_info');?></span>
    </div> -->

    
    
   
</div>
<br>
<div class="row">
    <div class="col-md-12">
      
            <button type="submit" class="btn btn-success" style="width: 100%">Update</button>
       
    </div>
</div>
<?php echo form_close(); ?>

