<div class="row">
    <div class="col-md-12">
        <h2>Add Patients Information</h2>
    </div>
</div>

<?php echo form_open('patients/add'); ?>
<div class="row">
     <div class="col-md-4">
                    <label class="control-label">Title</label>
                    <div class="form-group">
                     <select class="form-control"  name="title" id="title" >
                            <option value="">- - - Select - - - </option>
                            <option value="Mr">Mr</option>
                            <option value="Mrs">Mrs</option>
                            <option value="Miss">Miss</option>
                            <option value="Ms">Ms</option>
                            <option value="Dr">Dr</option>
                           
                                  
                        </select>
                    </div>
                </div>
    <div class="col-md-4">
        <label for="name" class=" control-label"><span class="text-danger">*</span>Name</label>
        <input type="text" name="name" value="<?php echo $this->input->post('name'); ?>" class="form-control" id="name" required />
        <span class="text-danger"><?php echo form_error('name');?></span>
    </div>
    <div class="col-md-4">
        <label for="surname" class=" control-label"><span class="text-danger">*</span>Surname</label>
        <input type="text" name="surname" value="<?php echo $this->input->post('surname'); ?>" class="form-control" id="name" required />
        <span class="text-danger"><?php echo form_error('surname');?></span>
    </div>
      <div class="col-md-4">
          <label for="gender" class=" control-label"><span class="text-danger">*</span>Gender</label>
          <div class="radio">
            <label style="margin-right: 20px">
              <input type="radio" name="gender" value="1" style="margin-right: 10px" checked="checked">Male</label>
            <label>
            <input type="radio" name="gender" value="2" style="margin-right: 10px; margin-top: 12px">Female</label>
          </div>
        </div>
         <div class="col-md-4">
        <label for="lab_sub_no" class=" control-label"><span class="text-danger">*</span>Laboratory Submission No</label>
        <input type="text" name="lab_sub_no" value="<?php echo $this->input->post('lab_sub_no'); ?>" class="form-control" id="name"  />
        <span class="text-danger"><?php echo form_error('lab_sub_no');?></span>
    </div>
     <div class="col-md-4">
        <label for="tel" class=" control-label"><span class="text-danger">*</span>Tel</label>
        <input type="text" name="tel" value="<?php echo $this->input->post('tel'); ?>" class="form-control" id="name" required />
        <span class="text-danger"><?php echo form_error('tel');?></span>
    </div>
     <div class="col-md-12">
        <label for="email" class=" control-label"><span class="text-danger">*</span>Email</label>
        <input type="email" name="email" value="<?php echo $this->input->post('email'); ?>" class="form-control" id="email"  />
        <span class="text-danger"><?php echo form_error('email');?></span>
    </div>


     <div class="col-md-12">
  <label for="address" class=" control-label">Address</label>
        <textarea name="address" rows="6" class="form-control" placeholder="Enter Address ..." id="address" style="resize: none"><?php echo $this->input->post('address'); ?></textarea>
    </div>

     <div class="col-md-4">
        <label for="date_swab_taken" class=" control-label"><span class="text-danger">*</span>Date swab taken</label>
        <input type="Date" name="date_swab_taken" value="<?php echo $this->input->post('date_swab_taken'); ?>" class="form-control" id="date_swab_taken" required />
        <span class="text-danger"><?php echo form_error('date_swab_taken');?></span>
    </div>

  <!--   <div class="col-md-6" style="margin-top: 30px">
        <label class=" control-label">Case definition</label><br>
        <?php $types = array(
            'Suspected cases' => 'Suspected cases',
            'Screen' => 'Screen',
            'Fit to Fly' => 'Fit to Fly',
             );
            $count = 1;
            foreach($types as $key => $t){ ?>
            <label style="font-weight: normal;"><input type="checkbox" name="case_define[]" value="<?=$t?>"/>
            <?=$t?>
            </label><br>
            <?php } ?>
    </div> -->
  <!--   <div class="col-md-6" style="margin-top: 30px; margin-bottom: 20px">
        <label class=" control-label">Specimen information</label><br>
        <?php $types2 = array(
            'VTM Swab for PCR' => 'VTM Swab for PCR',
            'Blood for Antibody' => 'Blood for Antibody',
            'Both' => 'Both',
             );
            $count = 1;
            foreach($types2 as $key => $t){ ?>
            <label style="font-weight: normal;"><input type="checkbox" name="specimen_info[]" value="<?=$t?>"/>
            <?=$t?>
            </label><br>
            <?php } ?>
    </div> -->


    <div class="col-md-4">
        <label for="passport_no" class=" control-label"><span class="text-danger">*</span>Passport Number</label>
        <input type="text" name="passport_no" value="<?php echo $this->input->post('passport_no'); ?>" class="form-control" id="passport_no"  />
        <span class="text-danger"><?php echo form_error('passport_no');?></span>
    </div>
     <div class="col-md-4">
        <label for="dob" class=" control-label"><span class="text-danger">*</span>Date of Birth</label>
        <input type="Date" name="dob" value="<?php echo $this->input->post('dob'); ?>" class="form-control" id="dob" required />
        <span class="text-danger"><?php echo form_error('dob');?></span>
    </div>

      <!-- <div class="col-md-4">
        <label for="relevant_info" class=" control-label"><span class="text-danger">*</span>Relevant information</label>
        <input type="text" name="relevant_info" value="<?php echo $this->input->post('relevant_info'); ?>" class="form-control" id="relevant_info" />
        <span class="text-danger"><?php echo form_error('relevant_info');?></span>
    </div> -->

    
    
   
</div>
<br>
<div class="row">
    <div class="col-md-12">
      
            <button type="submit" class="btn btn-success" style="width: 100%">Save</button>
       
    </div>
</div>
<?php echo form_close(); ?>

