<div class="row">
    <div class="col-md-12">
        <h2>Assign test identifier</h2>
    </div>
</div>

<?php echo form_open('patients/assign/'.$assign['id'],array("class"=>"form-horizontal")); ?>
<div class="row">
     <div class="col-md-4">
                    <label class="control-label">Title</label>
                    <div class="form-group">
                     <select class="form-control"  name="title" id="title" readonly >
                            <option value="">- - - Select - - - </option>
                            <option <?php if($assign['title'] == "Mr") echo "selected"; ?> value="Mr">Mr</option>
                            <option <?php if($assign['title'] == "Mrs") echo "selected"; ?> value="Mrs">Mrs</option>
                            <option <?php if($assign['title'] == "Miss") echo "selected"; ?> value="Miss">Miss</option>
                            <option <?php if($assign['title'] == "Ms") echo "selected"; ?> value="Ms">Ms</option>
                            <option <?php if($assign['title'] == "Dr") echo "selected"; ?> value="Dr">Dr</option>
                           
                                  
                        </select>
                    </div>
                </div>
    <div class="col-md-4">
        <label for="name" class=" control-label"><span class="text-danger">*</span>Name</label>
        <input type="text" name="name" value="<?php echo ($this->input->post('name') ? $this->input->post('name') : $assign['name']); ?>" class="form-control" id="name" required readonly/>
        <span class="text-danger"><?php echo form_error('name');?></span>
    </div>
    <div class="col-md-4">
        <label for="surname" class=" control-label"><span class="text-danger">*</span>Surname</label>
        <input type="text" name="surname" value="<?php echo ($this->input->post('surname') ? $this->input->post('surname') : $assign['surname']); ?>" class="form-control" id="name" required readonly/>
        <span class="text-danger"><?php echo form_error('surname');?></span>
    </div>

      <div class="col-md-12 col-sm-6">
        <label>Test Identifier <span class="required">*</span></label>
        <select class="form-control select2" name="lab_sub_no" id="lab_sub_no">
       <option value="">Select Test Identifier</option>
        <?php foreach ($test_identifiers as $u) {
          $selected = ($u['id'] == $this->input->post('lab_sub_no')) ? ' selected="selected"' : "";?>
                        <option value="<?=$u['test_identifiers']?>"><?=$u['test_identifiers']?></option>
                        <?php }?>
        </select>
             <span class="text-danger"><?php echo form_error('lab_sub_no');?></span>
                            </div>
     
    
   
</div>
<br>
<div class="row">
    <div class="col-md-12">
      
            <button type="submit" class="btn btn-success" style="width: 100%">Update</button>
       
    </div>
</div>
<?php echo form_close(); ?>

