<div class="row">
    <div class="col-md-12">
        <h2>Update test identifiers</h2>
    </div>
</div>

<?php echo form_open('test_identifiers/edit/'.$test_identifiers['id'],array("class"=>"form-horizontal")); ?>
<div class="row">
    <div class="col-md-12">
        <label for="test_identifiers" class=" control-label"><span class="text-danger">*</span>Enter Test Identifier name</label>
        <input type="text" name="test_identifiers" value="<?php echo ($this->input->post('test_identifiers') ? $this->input->post('test_identifiers') : $test_identifiers['test_identifiers']); ?>" class="form-control" id="test_identifiers" required />
        <span class="text-danger"><?php echo form_error('test_identifiers');?></span>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="pull-right">
            <button type="submit" class="btn btn-success">Update</button>
        </div>
    </div>
</div>
<?php echo form_close(); ?>

