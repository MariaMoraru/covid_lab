<div class="pull-right">
	<a href="<?php echo site_url('test_identifiers/add'); ?>" class="btn btn-success">Add</a> <br>
</div>
<h1>All Test Identifiers</h1>
<table id="myTable" class="table table-striped table-bordered">
	<thead>
	<tr>
		<th>Sr. No</th>
		<th>Test Identifiers</th>
		<th>Date Created</th>
		<th>Created by</th>
		<th>Status</th>
		
		<th style="width: 15%">Actions</th>
	</tr>
	</thead>
    <tbody>
	<?php $count=0; foreach($test_identifiers as $u){ $count++; ?>
		<tr>
			<td><?php echo $count; ?></td>
			
			<td><?php echo $u['test_identifiers']; ?></td>
			<td><?php echo $u['date_created']; ?></td>
			<td><?php echo $u['created_by']; ?></td>
			<td>
				<?php if($u['assigned_status'] == ASSIGNED){
					echo 'ASSIGNED';
				}elseif($u['assigned_status'] == NOT_ASSIGNED){
					echo 'Not Assigned';
				} ?>
			</td>
			
			<td>
				<a href="<?php echo site_url('test_identifiers/edit/'.$u['id']); ?>" class="btn btn-info btn-xs">Edit</a>
				<a href="<?php echo site_url('test_identifiers/remove/'.$u['id']); ?>" class="btn btn-danger btn-xs">Delete</a>
			</td>
		</tr>
	<?php } ?>
	</tbody>
</table>
